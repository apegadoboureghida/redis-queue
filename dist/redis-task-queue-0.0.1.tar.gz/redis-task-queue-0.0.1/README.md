redis-task-queue
===============================

version number: 0.0.1
author: Andres Pegado

Overview
--------

A python package that can be installed with pip.

Installation / Usage
--------------------

To install use pip:

    $ pip install redis-task-queue


Or clone the repo:

    $ git clone https://github.com/apegadoboureghida/redis-task-queue.git
    $ python setup.py install

Contributing
------------

TBD

Example
-------

TBD
